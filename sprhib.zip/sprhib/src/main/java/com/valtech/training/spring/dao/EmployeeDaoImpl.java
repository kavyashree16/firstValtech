package com.valtech.training.spring.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.valtech.training.hibernate.Employee;

public class EmployeeDaoImpl implements EmployeeDAO {
	
	private SessionFactory sessionfactory;
	
	@Override
	public Employee saveEmployee(Employee emp) {
		Session ses = sessionfactory.getCurrentSession();
		ses.persist(emp);
		ses.close();
		return emp;
	}
	
	@Override
	public Employee loadEmployee(int empId) {
		Session ses = sessionfactory.getCurrentSession();
		Employee emp = (Employee) ses.load(Employee.class, empId);
		ses.close();
		return emp;
		
	}
	
	@Override
	public Employee updatEmployee(Employee emp) {
		Session ses = sessionfactory.getCurrentSession();
		emp = (Employee)ses.merge(emp);
		ses.close();
		return emp;
	}
	
	@Override
	public void deleteEmployee(Employee emp) {
		Session ses = sessionfactory.getCurrentSession();
		ses.delete(emp);
	}
	
	@Override
	public List<Employee> getAllEmployee(){
		Session ses = sessionfactory.getCurrentSession();
		List<Employee> emps = ses.createQuery("from Employee e").list();
		ses.close();
		return emps;
		
	}
	
	public void setSessionfactory(SessionFactory sessionfactory) {
		this.sessionfactory = sessionfactory;
	}

}
