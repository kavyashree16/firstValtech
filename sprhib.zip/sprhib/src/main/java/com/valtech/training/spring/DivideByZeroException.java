package com.valtech.training.spring;

public class DivideByZeroException extends Exception{
	
	public DivideByZeroException(String message) {
		
		super(message);
	}

}
