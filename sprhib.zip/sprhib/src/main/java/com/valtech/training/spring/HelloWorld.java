package com.valtech.training.spring;

public class HelloWorld {
	
	public String hello(String name) {
		return "Hello "+name;
	}

}
//after this an xml file, the config file
