package com.valtech.training.spring.service;

import com.valtech.training.hibernate.Employee;
import com.valtech.training.spring.dao.EmployeeDAO;

public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeDAO employeeDAO;
	
	@Override
	public Employee createEmployee(Employee e) {
		return employeeDAO.saveEmployee(e);
	
	}
	
	@Override
	public Employee makeActive(Employee e) {
		e.setActive(true);
		return employeeDAO.updatEmployee(e);
	}
	
	@Override
	public Employee makeInactive(Employee e) {
		e.setActive(false);
		return employeeDAO.updatEmployee(e);
	}
	
	@Override
	public Employee IncrementSalary(Employee e,float increment) {
		e.setSalary(e.getSalary()+increment);
		return employeeDAO.updatEmployee(e);
	}
	
	@Override
	public void incrementSalaryForAll(int increment) {
		employeeDAO.getAllEmployee().forEach(e -> e.setSalary(e.getSalary()+increment));
		
		
	}
	
	
	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}

}
