package com.valtech.training.spring;

public interface SimpleInterest {

	double computeinterest(int prin,int rate,int duration) throws DivideByZeroException;
	
}
